let fetch = require('node-fetch')
let handler = async (m, { text, command, conn }) => {

  if (!text) throw 'Masukan teks untuk diubah menjadi gambar'

  let response = await fetch(`https://botcahx.cyclic.app/dalle?text=${encodeURIComponent(text)}`)
  let image = await response.buffer()
  conn.sendFile(m.chat, image, 'aneh.jpg',  wm, m)

}
handler.command = handler.help = ['aiimg','aiimage','ai-image']
handler.tags = ['internet']

module.exports = handler